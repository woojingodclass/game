﻿using UnityEngine;
using System.Collections;

public class Key : MonoBehaviour {

    public int index = -1;
}
