﻿using UnityEngine;
using System.Collections;

public class MirrorEvent : MonoBehaviour {

    public Texture2D nomalTexture;
    public Texture2D scareTexture;
    public float scareTime = 3f;

  
    bool showscare = false;

   

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GetComponent<Renderer>().material.mainTexture = scareTexture;
         
            showscare = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (showscare)
        {
            scareTime -= Time.deltaTime;
            if (scareTime <= 0)
            {


                showscare = false;
            }
        }
    }
}
