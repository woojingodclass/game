﻿using UnityEngine;
using System.Collections;

public class FlinckingLight : MonoBehaviour {
    public float minTime = 0.05f;
    public float maxTime = 1.2f;
    private float timer;
    public AudioClip soundOn;
    private Light l;
	// Use this for initialization
	void Start () {
        l = GetComponent<Light>();
        timer = Random.Range(minTime,maxTime);
	}
	
	// Update is called once per frame
	void Update () {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            l.enabled = !l.enabled;
            // GetComponent<AudioSource>().clip = soundOn;
            GetComponent<AudioSource>().Play();
            timer = Random.Range(minTime, maxTime);
        }
	}
}
