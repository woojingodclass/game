﻿using UnityEngine;
using System.Collections;

public class PictureEvent : MonoBehaviour {

    public Texture2D nomalTexture;
    public Texture2D scareTexture;
    public AudioClip Scaresound;
    public float scareTime = 10f;
   
    AudioSource audio;
    bool showscare = false;

    void Start()
    {
        audio = GetComponent<AudioSource>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            GetComponent<Renderer>().material.mainTexture = scareTexture;
            audio.Stop();
            audio.loop = false;
            audio.clip = Scaresound;
            audio.volume = 1f;
            audio.Play();

            showscare = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (showscare)
        {
            scareTime -= Time.deltaTime;
            if (scareTime <= 0)
            {
            

                showscare = false;
            }
        }
    }
}
